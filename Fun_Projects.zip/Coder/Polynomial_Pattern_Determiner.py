def PolDet(degree,pattern) :

    from Rv import Rv
    from Pascals_Triangle import Pascal
    coefficients=[]
    x=0
    while x <= degree :
        L=[]
        R=Pascal(degree-x)
        g=0
        while g <= degree-x :
            V=pattern[degree-x-g]*R[g]
            L.append(V)
            g += 1
        j = 0
        J=[]
        while j <= degree:
            G = Rv(degree - x, degree - j, degree - x + 1)
            J.append(G)
            j += 1
        if  len(coefficients) == 0 :
            R = (sum(L)) / (Rv(degree, degree, degree))
            coefficients.append(R)
        else :
            h=0
            W=[]
            while h <= degree :
                f=0
                try :
                    while f <= x :
                        R=J[h+f]*coefficients[h+f]
                        W.append(R)
                        f += 1
                except IndexError :
                    break
                break
            R = (sum(L)-sum(W)) / (Rv(degree-x, degree-x, degree-x))
            coefficients.append(R)
        L.clear()
        J.clear()
        x += 1
    return coefficients