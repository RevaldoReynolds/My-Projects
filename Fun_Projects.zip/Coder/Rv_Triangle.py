from Rv import Rv
l=0
n=12
H=[]
while l <= n :
    k=0
    while k <= l :
        P= Rv(k,l,k+1)
        H.append(P)
        k += 1
    print(H)
    print(sum(H))
    l += 1
    H.clear()