from Nkwinikan_Operator import Nkw
from Nk import Nk
import math
from Pascals_Triangle import Pascal
from Rv import Rv

l = 0
n = 11
H = []
Sum = []
while l <= n:
    k = 0
    while k <= l:
        P = Nk(k, l)
        H.append(P)
        k += 1
    print(H)
    print(sum(H))
    l += 1
    H.clear()
