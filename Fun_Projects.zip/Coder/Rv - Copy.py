
def Rv( n , p , m ) :
    import math
    x=0
    Y=[]
    while x<= n :
        V=((math.factorial(n))*((m-x)**p)*((-1)**x))/((math.factorial(x))*(math.factorial(n-x)))
        Y.append(V)
        x+=1
    return (sum(Y))
