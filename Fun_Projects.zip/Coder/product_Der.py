from Polynomial_Pattern_Determiner import PolDet
from Nk import Nk
from Rv import Rv
import math
l=0
n=3
V=[]
while l <= n-1 :
    C=Nk(l,n)*((n-l)**n)*(n**(n-l))*(((n-l)/n)+(math.log((((math.e)**(n/(n-l)))*(n-l)),math.e)))
    V.append(C)
    l += 1
print(V)