import PyPDF2


def rotator(FileName, Angle,pagenumber) :
    reader = PyPDF2.PdfFileReader(open(f'{FileName}','rb'))
    page = reader.getPage(pagenumber-1)
    page.rotateCounterClockwise(Angle)
    Writer = PyPDF2.PdfFileWriter()
    Writer.addPage(page)
    Name=(FileName.split('/')[-1]).split('.')[0]
    Writer.write(open(f'Rotated {Name} Page {pagenumber} .pdf','wb'))



rotator('./PDFprocessin/TwoPager.pdf',360,2)



