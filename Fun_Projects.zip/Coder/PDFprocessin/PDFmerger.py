import PyPDF2

def Merger(*Filenames) :
    merger=PyPDF2.PdfFileMerger()
    for File in Filenames:
        merger.append(File)
    merger.write(f'MergedFiles({Filenames[0]} - {Filenames[-1]}).pdf')


Merger('Rotated Dummy Page 1 .pdf','Rotated TwoPager Page 1 .pdf','Rotated TwoPager Page 2 .pdf','Rotated wtr Page 1 .pdf')