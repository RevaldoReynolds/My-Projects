# def Primes_Under(n) :
#     from array import array
#     '''
#     returns a list of primes under the number including n if it is prime
#     :param n: any positive integer
#     :return: list of primes under n if n is prime
#     '''
#     s = 2
#     P = array('i',[])
#     Potentials = array('i',[])
#     while s <= n:
#         Potentials.append(s)
#         s += 1
#     for p in  Potentials:
#         h = Potentials[0]
#         P.append(h)
#         d = 0
#         while d <= len(Potentials):
#             g = h * d
#             if g in Potentials:
#                 Potentials.remove(g)
#             d += 1
#     Primes = P + Potentials
#     return Primes
#
# number=13195
#
# def PrimeFactors(number) :
#     for p in Primes_Under(number) :
#         if number % p == 0 :
#             yield p
#
# print(max((PrimeFactors(13195))))
def Primefactors(Number) :
    def Primes_under(n) :
        from array import array
        k=2

        while k <= n :
            Pattern =array('i',[])
            for i in range(2,k) :
                v = k % i
                Pattern.append(v)
            if Pattern.count(0) == 0 :
                yield k
            k += 1
    # for i,p in enumerate(Primes_under(limit)) :
    #     if p >= limit :
    #         stop_at_number=i
    #         break

    for prime in Primes_under(7000) :
        if Number % prime == 0 :
            yield prime


print(list(Primefactors(600851475143)))