def Fibonacci(number):
    a = 0
    b = 1
    for i in range(number + 1):
        yield a
        temporary_value = a
        a = b
        b = a + temporary_value


number = 4000000

for i, n in enumerate(Fibonacci(number)):
    if n == number:
        stop_at_number = i
        break
    elif n > number:
        stop_at_number = i-1
        break

print(sum(k for k in Fibonacci(stop_at_number) if k % 2 == 0))
