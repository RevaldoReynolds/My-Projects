def Sum_of_multiples_3_or_5(n):
    for i in range(1, n):
        multi3 = 3 * i
        if multi3 < n:
            yield multi3

    for i in range(1, n):
        multi5 = 5 * i
        if multi5 < n:
            yield multi5


print(sum(set(Sum_of_multiples_3_or_5(1000))))
