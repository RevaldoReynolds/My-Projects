elif n == 16:
while a <= A:
    b = 1
    B = A - 2
    while b <= B:
        c = 1
        C = A - 3
        while c <= C:
            d = 1
            D = A - 4
            while d <= D:
                e = 1
                E = A - 5
                while e <= E:
                    f = 1
                    F = A - 6
                    while f <= F:
                        g = 1
                        G = A - 7
                        while g <= G:
                            h = 1
                            H = A - 8
                            while h <= H:
                                i = 1
                                I = A - 9
                                while i <= I:
                                    j = 1
                                    J = A - 10
                                    while j <= J:
                                        k = 1
                                        K = A - 11
                                        while k <= K:
                                            l = 1
                                            L = A - 12
                                            while l <= L:
                                                m = 1
                                                M = A - 13
                                                while m <= M:
                                                    o = 1
                                                    O = A - 14
                                                    while o <= O:
                                                        q = 1
                                                        Q = A - 15
                                                        while q <= Q:
                                                            for value in pattern[
                                                                         a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + 1:]:
                                                                p = pattern[a] * pattern[a + b] * pattern[a + b + c] * \
                                                                    pattern[
                                                                        a + b + c + d] * pattern[a + b + c + d + e] * \
                                                                    pattern[
                                                                        a + b + c + d + e + f] * pattern[
                                                                        a + b + c + d + e + f + g] * pattern[
                                                                        a + b + c + d + e + f + g + h] * pattern[
                                                                        a + b + c + d + e + f + g + h + i] * pattern[
                                                                        a + b + c + d + e + f + g + h + i + j] * \
                                                                    pattern[
                                                                        a + b + c + d + e + f + g + h + i + j + k] * \
                                                                    pattern[
                                                                        a + b + c + d + e + f + g + h + i + j + k + l] * \
                                                                    pattern[
                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m] * \
                                                                    pattern[
                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o] * \
                                                                    pattern[
                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q] * value
                                                                result.append(p)
                                                            q += 1
                                                        o += 1
                                                    m += 1
                                                l += 1
                                            k += 1
                                        j += 1
                                    i += 1
                                h += 1
                            g += 1
                        f += 1
                    e += 1
                d += 1
            c += 1
        b += 1
    a += 1
# Seventeenth
elif n == 17:
while a <= A:
    b = 1
    B = A - 2
    while b <= B:
        c = 1
        C = A - 3
        while c <= C:
            d = 1
            D = A - 4
            while d <= D:
                e = 1
                E = A - 5
                while e <= E:
                    f = 1
                    F = A - 6
                    while f <= F:
                        g = 1
                        G = A - 7
                        while g <= G:
                            h = 1
                            H = A - 8
                            while h <= H:
                                i = 1
                                I = A - 9
                                while i <= I:
                                    j = 1
                                    J = A - 10
                                    while j <= J:
                                        k = 1
                                        K = A - 11
                                        while k <= K:
                                            l = 1
                                            L = A - 12
                                            while l <= L:
                                                m = 1
                                                M = A - 13
                                                while m <= M:
                                                    o = 1
                                                    O = A - 14
                                                    while o <= O:
                                                        q = 1
                                                        Q = A - 15
                                                        while q <= Q:
                                                            r = 1
                                                            R = A - 16
                                                            while r <= R:
                                                                for value in pattern[
                                                                             a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + 1:]:
                                                                    p = pattern[a] * pattern[a + b] * pattern[
                                                                        a + b + c] * pattern[
                                                                            a + b + c + d] * pattern[
                                                                            a + b + c + d + e] * pattern[
                                                                            a + b + c + d + e + f] * pattern[
                                                                            a + b + c + d + e + f + g] * pattern[
                                                                            a + b + c + d + e + f + g + h] * pattern[
                                                                            a + b + c + d + e + f + g + h + i] * \
                                                                        pattern[
                                                                            a + b + c + d + e + f + g + h + i + j] * \
                                                                        pattern[
                                                                            a + b + c + d + e + f + g + h + i + j + k] * \
                                                                        pattern[
                                                                            a + b + c + d + e + f + g + h + i + j + k + l] * \
                                                                        pattern[
                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m] * \
                                                                        pattern[
                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m + o] * \
                                                                        pattern[
                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m + o + q] * \
                                                                        pattern[
                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r] * value
                                                                    result.append(p)
                                                                r += 1
                                                            q += 1
                                                        o += 1
                                                    m += 1
                                                l += 1
                                            k += 1
                                        j += 1
                                    i += 1
                                h += 1
                            g += 1
                        f += 1
                    e += 1
                d += 1
            c += 1
        b += 1
    a += 1
# Eighteenth
elif n == 18:
while a <= A:
    b = 1
    B = A - 2
    while b <= B:
        c = 1
        C = A - 3
        while c <= C:
            d = 1
            D = A - 4
            while d <= D:
                e = 1
                E = A - 5
                while e <= E:
                    f = 1
                    F = A - 6
                    while f <= F:
                        g = 1
                        G = A - 7
                        while g <= G:
                            h = 1
                            H = A - 8
                            while h <= H:
                                i = 1
                                I = A - 9
                                while i <= I:
                                    j = 1
                                    J = A - 10
                                    while j <= J:
                                        k = 1
                                        K = A - 11
                                        while k <= K:
                                            l = 1
                                            L = A - 12
                                            while l <= L:
                                                m = 1
                                                M = A - 13
                                                while m <= M:
                                                    o = 1
                                                    O = A - 14
                                                    while o <= O:
                                                        q = 1
                                                        Q = A - 15
                                                        while q <= Q:
                                                            r = 1
                                                            R = A - 16
                                                            while r <= R:
                                                                s = 1
                                                                S = A - 17
                                                                while s <= S:
                                                                    for value in pattern[
                                                                                 a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + 1:]:
                                                                        p = pattern[a] * pattern[a + b] * pattern[
                                                                            a + b + c] * pattern[
                                                                                a + b + c + d] * pattern[
                                                                                a + b + c + d + e] * pattern[
                                                                                a + b + c + d + e + f] * pattern[
                                                                                a + b + c + d + e + f + g] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f + g + h] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f + g + h + i] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f + g + h + i + j] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f + g + h + i + j + k] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f + g + h + i + j + k + l] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o + q] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s] * value
                                                                        result.append(p)
                                                                    s += 1
                                                                r += 1
                                                            q += 1
                                                        o += 1
                                                    m += 1
                                                l += 1
                                            k += 1
                                        j += 1
                                    i += 1
                                h += 1
                            g += 1
                        f += 1
                    e += 1
                d += 1
            c += 1
        b += 1
    a += 1
# Nineteenth
elif n == 19:
while a <= A:
    b = 1
    B = A - 2
    while b <= B:
        c = 1
        C = A - 3
        while c <= C:
            d = 1
            D = A - 4
            while d <= D:
                e = 1
                E = A - 5
                while e <= E:
                    f = 1
                    F = A - 6
                    while f <= F:
                        g = 1
                        G = A - 7
                        while g <= G:
                            h = 1
                            H = A - 8
                            while h <= H:
                                i = 1
                                I = A - 9
                                while i <= I:
                                    j = 1
                                    J = A - 10
                                    while j <= J:
                                        k = 1
                                        K = A - 11
                                        while k <= K:
                                            l = 1
                                            L = A - 12
                                            while l <= L:
                                                m = 1
                                                M = A - 13
                                                while m <= M:
                                                    o = 1
                                                    O = A - 14
                                                    while o <= O:
                                                        q = 1
                                                        Q = A - 15
                                                        while q <= Q:
                                                            r = 1
                                                            R = A - 16
                                                            while r <= R:
                                                                s = 1
                                                                S = A - 17
                                                                while s <= S:
                                                                    t = 1
                                                                    T = A - 18
                                                                    while t <= T:
                                                                        for value in pattern[
                                                                                     a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + 1:]:
                                                                            p = pattern[a] * pattern[a + b] * pattern[
                                                                                a + b + c] * pattern[
                                                                                    a + b + c + d] * pattern[
                                                                                    a + b + c + d + e] * pattern[
                                                                                    a + b + c + d + e + f] * pattern[
                                                                                    a + b + c + d + e + f + g] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i + j] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i + j + k] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i + j + k + l] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m + o] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m + o + q] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t] * value
                                                                            result.append(p)
                                                                        t += 1
                                                                    s += 1
                                                                r += 1
                                                            q += 1
                                                        o += 1
                                                    m += 1
                                                l += 1
                                            k += 1
                                        j += 1
                                    i += 1
                                h += 1
                            g += 1
                        f += 1
                    e += 1
                d += 1
            c += 1
        b += 1
    a += 1
# Twentieth
elif n == 20:
while a <= A:
    b = 1
    B = A - 2
    while b <= B:
        c = 1
        C = A - 3
        while c <= C:
            d = 1
            D = A - 4
            while d <= D:
                e = 1
                E = A - 5
                while e <= E:
                    f = 1
                    F = A - 6
                    while f <= F:
                        g = 1
                        G = A - 7
                        while g <= G:
                            h = 1
                            H = A - 8
                            while h <= H:
                                i = 1
                                I = A - 9
                                while i <= I:
                                    j = 1
                                    J = A - 10
                                    while j <= J:
                                        k = 1
                                        K = A - 11
                                        while k <= K:
                                            l = 1
                                            L = A - 12
                                            while l <= L:
                                                m = 1
                                                M = A - 13
                                                while m <= M:
                                                    o = 1
                                                    O = A - 14
                                                    while o <= O:
                                                        q = 1
                                                        Q = A - 15
                                                        while q <= Q:
                                                            r = 1
                                                            R = A - 16
                                                            while r <= R:
                                                                s = 1
                                                                S = A - 17
                                                                while s <= S:
                                                                    t = 1
                                                                    T = A - 18
                                                                    while t <= T:
                                                                        u = 1
                                                                        U = A - 19
                                                                        while u <= U:
                                                                            for value in pattern[
                                                                                         a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u + 1:]:
                                                                                p = pattern[a] * pattern[a + b] * \
                                                                                    pattern[
                                                                                        a + b + c] * pattern[
                                                                                        a + b + c + d] * pattern[
                                                                                        a + b + c + d + e] * pattern[
                                                                                        a + b + c + d + e + f] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j + k] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j + k + l] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u] * value
                                                                                result.append(p)
                                                                            u += 1
                                                                        t += 1
                                                                    s += 1
                                                                r += 1
                                                            q += 1
                                                        o += 1
                                                    m += 1
                                                l += 1
                                            k += 1
                                        j += 1
                                    i += 1
                                h += 1
                            g += 1
                        f += 1
                    e += 1
                d += 1
            c += 1
        b += 1
    a += 1
# 21st
elif n == 21:
while a <= A:
    b = 1
    B = A - 2
    while b <= B:
        c = 1
        C = A - 3
        while c <= C:
            d = 1
            D = A - 4
            while d <= D:
                e = 1
                E = A - 5
                while e <= E:
                    f = 1
                    F = A - 6
                    while f <= F:
                        g = 1
                        G = A - 7
                        while g <= G:
                            h = 1
                            H = A - 8
                            while h <= H:
                                i = 1
                                I = A - 9
                                while i <= I:
                                    j = 1
                                    J = A - 10
                                    while j <= J:
                                        k = 1
                                        K = A - 11
                                        while k <= K:
                                            l = 1
                                            L = A - 12
                                            while l <= L:
                                                m = 1
                                                M = A - 13
                                                while m <= M:
                                                    o = 1
                                                    O = A - 14
                                                    while o <= O:
                                                        q = 1
                                                        Q = A - 15
                                                        while q <= Q:
                                                            r = 1
                                                            R = A - 16
                                                            while r <= R:
                                                                s = 1
                                                                S = A - 17
                                                                while s <= S:
                                                                    t = 1
                                                                    T = A - 18
                                                                    while t <= T:
                                                                        u = 1
                                                                        U = A - 19
                                                                        while u <= U:
                                                                            v = 1
                                                                            V = A - 20
                                                                            while v <= V:
                                                                                for value in pattern[
                                                                                             a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u + v + 1:]:
                                                                                    p = pattern[a] * pattern[
                                                                                        a + b] * pattern[
                                                                                            a + b + c] * pattern[
                                                                                            a + b + c + d] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k + l] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m + o] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m + o + q] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u + v] * value
                                                                                    result.append(p)
                                                                                v += 1
                                                                            u += 1
                                                                        t += 1
                                                                    s += 1
                                                                r += 1
                                                            q += 1
                                                        o += 1
                                                    m += 1
                                                l += 1
                                            k += 1
                                        j += 1
                                    i += 1
                                h += 1
                            g += 1
                        f += 1
                    e += 1
                d += 1
            c += 1
        b += 1
    a += 1
# 22nd
elif n == 22:
while a <= A:
    b = 1
    B = A - 2
    while b <= B:
        c = 1
        C = A - 3
        while c <= C:
            d = 1
            D = A - 4
            while d <= D:
                e = 1
                E = A - 5
                while e <= E:
                    f = 1
                    F = A - 6
                    while f <= F:
                        g = 1
                        G = A - 7
                        while g <= G:
                            h = 1
                            H = A - 8
                            while h <= H:
                                i = 1
                                I = A - 9
                                while i <= I:
                                    j = 1
                                    J = A - 10
                                    while j <= J:
                                        k = 1
                                        K = A - 11
                                        while k <= K:
                                            l = 1
                                            L = A - 12
                                            while l <= L:
                                                m = 1
                                                M = A - 13
                                                while m <= M:
                                                    o = 1
                                                    O = A - 14
                                                    while o <= O:
                                                        q = 1
                                                        Q = A - 15
                                                        while q <= Q:
                                                            r = 1
                                                            R = A - 16
                                                            while r <= R:
                                                                s = 1
                                                                S = A - 17
                                                                while s <= S:
                                                                    t = 1
                                                                    T = A - 18
                                                                    while t <= T:
                                                                        u = 1
                                                                        U = A - 19
                                                                        while u <= U:
                                                                            v = 1
                                                                            V = A - 20
                                                                            while v <= V:
                                                                                w = 1
                                                                                W = A - 21
                                                                                while w <= W:
                                                                                    for value in pattern[
                                                                                                 a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u + v + w + 1:]:
                                                                                        p = pattern[a] * pattern[
                                                                                            a + b] * pattern[
                                                                                                a + b + c] * pattern[
                                                                                                a + b + c + d] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o + q] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u + v] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u + v + w] * value
                                                                                        result.append(p)
                                                                                    w += 1
                                                                                v += 1
                                                                            u += 1
                                                                        t += 1
                                                                    s += 1
                                                                r += 1
                                                            q += 1
                                                        o += 1
                                                    m += 1
                                                l += 1
                                            k += 1
                                        j += 1
                                    i += 1
                                h += 1
                            g += 1
                        f += 1
                    e += 1
                d += 1
            c += 1
        b += 1
    a += 1
# 23rd
elif n == 23:
while a <= A:
    b = 1
    B = A - 2
    while b <= B:
        c = 1
        C = A - 3
        while c <= C:
            d = 1
            D = A - 4
            while d <= D:
                e = 1
                E = A - 5
                while e <= E:
                    f = 1
                    F = A - 6
                    while f <= F:
                        g = 1
                        G = A - 7
                        while g <= G:
                            h = 1
                            H = A - 8
                            while h <= H:
                                i = 1
                                I = A - 9
                                while i <= I:
                                    j = 1
                                    J = A - 10
                                    while j <= J:
                                        k = 1
                                        K = A - 11
                                        while k <= K:
                                            l = 1
                                            L = A - 12
                                            while l <= L:
                                                m = 1
                                                M = A - 13
                                                while m <= M:
                                                    o = 1
                                                    O = A - 14
                                                    while o <= O:
                                                        q = 1
                                                        Q = A - 15
                                                        while q <= Q:
                                                            r = 1
                                                            R = A - 16
                                                            while r <= R:
                                                                s = 1
                                                                S = A - 17
                                                                while s <= S:
                                                                    t = 1
                                                                    T = A - 18
                                                                    while t <= T:
                                                                        u = 1
                                                                        U = A - 19
                                                                        while u <= U:
                                                                            v = 1
                                                                            V = A - 20
                                                                            while v <= V:
                                                                                w = 1
                                                                                W = A - 21
                                                                                while w <= W:
                                                                                    x = 1
                                                                                    X = A - 22
                                                                                    while x <= X:
                                                                                        for value in pattern[
                                                                                                     a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u + v + w + x + 1:]:
                                                                                            p = pattern[a] * \
                                                                                                pattern[
                                                                                                    a + b] * \
                                                                                                pattern[
                                                                                                    a + b + c] * \
                                                                                                pattern[
                                                                                                    a + b + c + d] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e + f] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e + f + g] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e + f + g + h] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e + f + g + h + i] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e + f + g + h + i + j] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e + f + g + h + i + j + k] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e + f + g + h + i + j + k + l] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m + o] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m + o + q] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u + v] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u + v + w] * \
                                                                                                pattern[
                                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u + v + w + x] * value
                                                                                            result.append(p)
                                                                                        x += 1
                                                                                    w += 1
                                                                                v += 1
                                                                            u += 1
                                                                        t += 1
                                                                    s += 1
                                                                r += 1
                                                            q += 1
                                                        o += 1
                                                    m += 1
                                                l += 1
                                            k += 1
                                        j += 1
                                    i += 1
                                h += 1
                            g += 1
                        f += 1
                    e += 1
                d += 1
            c += 1
        b += 1
    a += 1
# 24th
elif n == 24:
while a <= A:
    b = 1
    B = A - 2
    while b <= B:
        c = 1
        C = A - 3
        while c <= C:
            d = 1
            D = A - 4
            while d <= D:
                e = 1
                E = A - 5
                while e <= E:
                    f = 1
                    F = A - 6
                    while f <= F:
                        g = 1
                        G = A - 7
                        while g <= G:
                            h = 1
                            H = A - 8
                            while h <= H:
                                i = 1
                                I = A - 9
                                while i <= I:
                                    j = 1
                                    J = A - 10
                                    while j <= J:
                                        k = 1
                                        K = A - 11
                                        while k <= K:
                                            l = 1
                                            L = A - 12
                                            while l <= L:
                                                m = 1
                                                M = A - 13
                                                while m <= M:
                                                    o = 1
                                                    O = A - 14
                                                    while o <= O:
                                                        q = 1
                                                        Q = A - 15
                                                        while q <= Q:
                                                            r = 1
                                                            R = A - 16
                                                            while r <= R:
                                                                s = 1
                                                                S = A - 17
                                                                while s <= S:
                                                                    t = 1
                                                                    T = A - 18
                                                                    while t <= T:
                                                                        u = 1
                                                                        U = A - 19
                                                                        while u <= U:
                                                                            v = 1
                                                                            V = A - 20
                                                                            while v <= V:
                                                                                w = 1
                                                                                W = A - 21
                                                                                while w <= W:
                                                                                    x = 1
                                                                                    X = A - 22
                                                                                    while x <= X:
                                                                                        y = 1
                                                                                        Y = A - 23
                                                                                        while y <= Y:
                                                                                            for value in pattern[
                                                                                                         a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u + v + w + x + y + 1:]:
                                                                                                p = pattern[a] * \
                                                                                                    pattern[
                                                                                                        a + b] * \
                                                                                                    pattern[
                                                                                                        a + b + c] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f + g] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f + g + h] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f + g + h + i] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f + g + h + i + j] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f + g + h + i + j + k] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f + g + h + i + j + k + l] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u + v] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u + v + w] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u + v + w + x] * \
                                                                                                    pattern[
                                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u + v + w + x + y] * value
                                                                                                result.append(p)
                                                                                            y += 1
                                                                                        x += 1
                                                                                    w += 1
                                                                                v += 1
                                                                            u += 1
                                                                        t += 1
                                                                    s += 1
                                                                r += 1
                                                            q += 1
                                                        o += 1
                                                    m += 1
                                                l += 1
                                            k += 1
                                        j += 1
                                    i += 1
                                h += 1
                            g += 1
                        f += 1
                    e += 1
                d += 1
            c += 1
        b += 1
    a += 1
else:
    print('Out of Range')
while d <= D:
    e = 1
    E = A - 5
    while e <= E:
        f = 1
        F = A - 6
        while f <= F:
            g = 1
            G = A - 7
            while g <= G:
                h = 1
                H = A - 8
                while h <= H:
                    i = 1
                    I = A - 9
                    while i <= I:
                        j = 1
                        J = A - 10
                        while j <= J:
                            k = 1
                            K = A - 11
                            while k <= K:

r