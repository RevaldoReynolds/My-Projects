def Nkwiks(n, pattern):
    A = len(pattern)
    a = 0
    result = []
    # Negativeth
    if n < 0:
        result = [0]
    # Zeroth
    elif n == 0:
        result = [1]
    # First
    elif n == 1:
        for value in pattern:
            p = value
            result.append(p)
    # second
    elif n == 2:
        while a <= A:
            for value in pattern[a + 1:]:
                p = pattern[a] * value
                result.append(p)
            a += 1
    # Third
    elif n == 3:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                for value in pattern[a + b + 1:]:
                    p = pattern[a] * pattern[a + b] * value
                    result.append(p)
                b += 1
            a += 1
    # Fourth
    elif n == 4:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                c = 1
                C = A - 3
                while c <= C:
                    for value in pattern[a + b + c + 1:]:
                        p = pattern[a] * pattern[a + b] * pattern[a + b + c] * value
                        result.append(p)
                    c += 1
                b += 1
            a += 1
    # Fifth
    elif n == 5:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                c = 1
                C = A - 3
                while c <= C:
                    d = 1
                    D = A - 4
                    while d <= D:
                        for value in pattern[a + b + c + d + 1:]:
                            p = pattern[a] * pattern[a + b] * pattern[a + b + c] * pattern[a + b + c + d] * value
                            result.append(p)
                        d += 1
                    c += 1
                b += 1
            a += 1
    # Sixth
    elif n == 6:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                c = 1
                C = A - 3
                while c <= C:
                    d = 1
                    D = A - 4
                    while d <= D:
                        e = 1
                        E = A - 5
                        while e <= E:
                            for value in pattern[a + b + c + d + e + 1:]:
                                p = pattern[a] * pattern[a + b] * pattern[a + b + c] * pattern[a + b + c + d] * pattern[
                                    a + b + c + d + e] * value
                                result.append(p)
                            e += 1
                        d += 1
                    c += 1
                b += 1
            a += 1
    # Seventh
    elif n == 7:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                c = 1
                C = A - 3
                while c <= C:
                    d = 1
                    D = A - 4
                    while d <= D:
                        e = 1
                        E = A - 5
                        while e <= E:
                            f = 1
                            F = A - 6
                            while f <= F:
                                for value in pattern[a + b + c + d + e + f + 1:]:
                                    p = pattern[a] * pattern[a + b] * pattern[a + b + c] * pattern[a + b + c + d] * \
                                        pattern[a + b + c + d + e] * pattern[a + b + c + d + e + f] * value
                                    result.append(p)
                                f += 1
                            e += 1
                        d += 1
                    c += 1
                b += 1
            a += 1
    # Eighth
    elif n == 8:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                c = 1
                C = A - 3
                while c <= C:
                    d = 1
                    D = A - 4
                    while d <= D:
                        e = 1
                        E = A - 5
                        while e <= E:
                            f = 1
                            F = A - 6
                            while f <= F:
                                g = 1
                                G = A - 7
                                while g <= G:
                                    for value in pattern[a + b + c + d + e + f + g + 1:]:
                                        p = pattern[a] * pattern[a + b] * pattern[a + b + c] * pattern[a + b + c + d] * \
                                            pattern[a + b + c + d + e] * pattern[a + b + c + d + e + f] * pattern[
                                                a + b + c + d + e + f + g] * value
                                        result.append(p)
                                    g += 1
                                f += 1
                            e += 1
                        d += 1
                    c += 1
                b += 1
            a += 1
    # Ninth
    elif n == 9:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                c = 1
                C = A - 3
                while c <= C:
                    d = 1
                    D = A - 4
                    while d <= D:
                        e = 1
                        E = A - 5
                        while e <= E:
                            f = 1
                            F = A - 6
                            while f <= F:
                                g = 1
                                G = A - 7
                                while g <= G:
                                    h = 1
                                    H = A - 8
                                    while h <= H:
                                        for value in pattern[a + b + c + d + e + f + g + h + 1:]:
                                            p = pattern[a] * pattern[a + b] * pattern[a + b + c] * pattern[
                                                a + b + c + d] * pattern[a + b + c + d + e] * pattern[
                                                    a + b + c + d + e + f] * pattern[a + b + c + d + e + f + g] * \
                                                pattern[a + b + c + d + e + f + g + h] * value
                                            result.append(p)
                                        h += 1
                                    g += 1
                                f += 1
                            e += 1
                        d += 1
                    c += 1
                b += 1
            a += 1
    # Tenth
    elif n == 10:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                c = 1
                C = A - 3
                while c <= C:
                    d = 1
                    D = A - 4
                    while d <= D:
                        e = 1
                        E = A - 5
                        while e <= E:
                            f = 1
                            F = A - 6
                            while f <= F:
                                g = 1
                                G = A - 7
                                while g <= G:
                                    h = 1
                                    H = A - 8
                                    while h <= H:
                                        i = 1
                                        I = A - 9
                                        while i <= I:
                                            for value in pattern[a + b + c + d + e + f + g + h + i + 1:]:
                                                p = pattern[a] * pattern[a + b] * pattern[a + b + c] * pattern[
                                                    a + b + c + d] * pattern[a + b + c + d + e] * pattern[
                                                        a + b + c + d + e + f] * pattern[a + b + c + d + e + f + g] * \
                                                    pattern[a + b + c + d + e + f + g + h] * pattern[
                                                        a + b + c + d + e + f + g + h + i] * value
                                                result.append(p)
                                            i += 1
                                        h += 1
                                    g += 1
                                f += 1
                            e += 1
                        d += 1
                    c += 1
                b += 1
            a += 1
    # Eleventh
    elif n == 11:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                c = 1
                C = A - 3
                while c <= C:
                    d = 1
                    D = A - 4
                    while d <= D:
                        e = 1
                        E = A - 5
                        while e <= E:
                            f = 1
                            F = A - 6
                            while f <= F:
                                g = 1
                                G = A - 7
                                while g <= G:
                                    h = 1
                                    H = A - 8
                                    while h <= H:
                                        i = 1
                                        I = A - 9
                                        while i <= I:
                                            j = 1
                                            J = A - 10
                                            while j <= J:
                                                for value in pattern[a + b + c + d + e + f + g + h + i + j + 1:]:
                                                    p = pattern[a] * pattern[a + b] * pattern[a + b + c] * pattern[
                                                        a + b + c + d] * pattern[a + b + c + d + e] * pattern[
                                                            a + b + c + d + e + f] * pattern[
                                                            a + b + c + d + e + f + g] * pattern[
                                                            a + b + c + d + e + f + g + h] * pattern[
                                                            a + b + c + d + e + f + g + h + i] * pattern[
                                                            a + b + c + d + e + f + g + h + i + j] * value
                                                    result.append(p)
                                                j += 1
                                            i += 1
                                        h += 1
                                    g += 1
                                f += 1
                            e += 1
                        d += 1
                    c += 1
                b += 1
            a += 1
    # Twelfth
    elif n == 12:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                c = 1
                C = A - 3
                while c <= C:
                    d = 1
                    D = A - 4
                    while d <= D:
                        e = 1
                        E = A - 5
                        while e <= E:
                            f = 1
                            F = A - 6
                            while f <= F:
                                g = 1
                                G = A - 7
                                while g <= G:
                                    h = 1
                                    H = A - 8
                                    while h <= H:
                                        i = 1
                                        I = A - 9
                                        while i <= I:
                                            j = 1
                                            J = A - 10
                                            while j <= J:
                                                k = 1
                                                K = A - 11
                                                while k <= K:
                                                    for value in pattern[
                                                                 a + b + c + d + e + f + g + h + i + j + k + 1:]:
                                                        p = pattern[a] * pattern[a + b] * pattern[a + b + c] * pattern[
                                                            a + b + c + d] * pattern[a + b + c + d + e] * pattern[
                                                                a + b + c + d + e + f] * pattern[
                                                                a + b + c + d + e + f + g] * pattern[
                                                                a + b + c + d + e + f + g + h] * pattern[
                                                                a + b + c + d + e + f + g + h + i] * pattern[
                                                                a + b + c + d + e + f + g + h + i + j] * pattern[
                                                                a + b + c + d + e + f + g + h + i + j + k] * value
                                                        result.append(p)
                                                    k += 1
                                                j += 1
                                            i += 1
                                        h += 1
                                    g += 1
                                f += 1
                            e += 1
                        d += 1
                    c += 1
                b += 1
            a += 1
    # Thirteenth
    elif n == 13:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                c = 1
                C = A - 3
                while c <= C:
                    d = 1
                    D = A - 4
                    while d <= D:
                        e = 1
                        E = A - 5
                        while e <= E:
                            f = 1
                            F = A - 6
                            while f <= F:
                                g = 1
                                G = A - 7
                                while g <= G:
                                    h = 1
                                    H = A - 8
                                    while h <= H:
                                        i = 1
                                        I = A - 9
                                        while i <= I:
                                            j = 1
                                            J = A - 10
                                            while j <= J:
                                                k = 1
                                                K = A - 11
                                                while k <= K:
                                                    l = 1
                                                    L = A - 12
                                                    while l <= L:
                                                        for value in pattern[
                                                                     a + b + c + d + e + f + g + h + i + j + k + l + 1:]:
                                                            p = pattern[a] * pattern[a + b] * pattern[a + b + c] * \
                                                                pattern[
                                                                    a + b + c + d] * pattern[a + b + c + d + e] * \
                                                                pattern[
                                                                    a + b + c + d + e + f] * pattern[
                                                                    a + b + c + d + e + f + g] * pattern[
                                                                    a + b + c + d + e + f + g + h] * pattern[
                                                                    a + b + c + d + e + f + g + h + i] * pattern[
                                                                    a + b + c + d + e + f + g + h + i + j] * pattern[
                                                                    a + b + c + d + e + f + g + h + i + j + k] * \
                                                                pattern[
                                                                    a + b + c + d + e + f + g + h + i + j + k + l] * value
                                                            result.append(p)
                                                        l += 1
                                                    k += 1
                                                j += 1
                                            i += 1
                                        h += 1
                                    g += 1
                                f += 1
                            e += 1
                        d += 1
                    c += 1
                b += 1
            a += 1
    # Fourteenth
    elif n == 14:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                c = 1
                C = A - 3
                while c <= C:
                    d = 1
                    D = A - 4
                    while d <= D:
                        e = 1
                        E = A - 5
                        while e <= E:
                            f = 1
                            F = A - 6
                            while f <= F:
                                g = 1
                                G = A - 7
                                while g <= G:
                                    h = 1
                                    H = A - 8
                                    while h <= H:
                                        i = 1
                                        I = A - 9
                                        while i <= I:
                                            j = 1
                                            J = A - 10
                                            while j <= J:
                                                k = 1
                                                K = A - 11
                                                while k <= K:
                                                    l = 1
                                                    L = A - 12
                                                    while l <= L:
                                                        m = 1
                                                        M = A - 13
                                                        while m <= M:
                                                            for value in pattern[
                                                                         a + b + c + d + e + f + g + h + i + j + k + l + m + 1:]:
                                                                p = pattern[a] * pattern[a + b] * pattern[a + b + c] * \
                                                                    pattern[
                                                                        a + b + c + d] * pattern[a + b + c + d + e] * \
                                                                    pattern[
                                                                        a + b + c + d + e + f] * pattern[
                                                                        a + b + c + d + e + f + g] * pattern[
                                                                        a + b + c + d + e + f + g + h] * pattern[
                                                                        a + b + c + d + e + f + g + h + i] * pattern[
                                                                        a + b + c + d + e + f + g + h + i + j] * \
                                                                    pattern[
                                                                        a + b + c + d + e + f + g + h + i + j + k] * \
                                                                    pattern[
                                                                        a + b + c + d + e + f + g + h + i + j + k + l] * \
                                                                    pattern[
                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m] * value
                                                                result.append(p)
                                                            m += 1
                                                        l += 1
                                                    k += 1
                                                j += 1
                                            i += 1
                                        h += 1
                                    g += 1
                                f += 1
                            e += 1
                        d += 1
                    c += 1
                b += 1
            a += 1
    # Fifteenth
    elif n == 15:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                c = 1
                C = A - 3
                while c <= C:
                    d = 1
                    D = A - 4
                    while d <= D:
                        e = 1
                        E = A - 5
                        while e <= E:
                            f = 1
                            F = A - 6
                            while f <= F:
                                g = 1
                                G = A - 7
                                while g <= G:
                                    h = 1
                                    H = A - 8
                                    while h <= H:
                                        i = 1
                                        I = A - 9
                                        while i <= I:
                                            j = 1
                                            J = A - 10
                                            while j <= J:
                                                k = 1
                                                K = A - 11
                                                while k <= K:
                                                    l = 1
                                                    L = A - 12
                                                    while l <= L:
                                                        m = 1
                                                        M = A - 13
                                                        while m <= M:
                                                            o = 1
                                                            O = A - 14
                                                            while o <= O:
                                                                for value in pattern[
                                                                             a + b + c + d + e + f + g + h + i + j + k + l + m + o + 1:]:
                                                                    p = pattern[a] * pattern[a + b] * pattern[
                                                                        a + b + c] * pattern[
                                                                            a + b + c + d] * pattern[
                                                                            a + b + c + d + e] * pattern[
                                                                            a + b + c + d + e + f] * pattern[
                                                                            a + b + c + d + e + f + g] * pattern[
                                                                            a + b + c + d + e + f + g + h] * pattern[
                                                                            a + b + c + d + e + f + g + h + i] * \
                                                                        pattern[
                                                                            a + b + c + d + e + f + g + h + i + j] * \
                                                                        pattern[
                                                                            a + b + c + d + e + f + g + h + i + j + k] * \
                                                                        pattern[
                                                                            a + b + c + d + e + f + g + h + i + j + k + l] * \
                                                                        pattern[
                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m] * \
                                                                        pattern[
                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m + o] * value
                                                                    result.append(p)
                                                                o += 1
                                                            m += 1
                                                        l += 1
                                                    k += 1
                                                j += 1
                                            i += 1
                                        h += 1
                                    g += 1
                                f += 1
                            e += 1
                        d += 1
                    c += 1
                b += 1
            a += 1
    elif n == 16:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                c = 1
                C = A - 3
                while c <= C:
                    d = 1
                    D = A - 4
                    while d <= D:
                        e = 1
                        E = A - 5
                        while e <= E:
                            f = 1
                            F = A - 6
                            while f <= F:
                                g = 1
                                G = A - 7
                                while g <= G:
                                    h = 1
                                    H = A - 8
                                    while h <= H:
                                        i = 1
                                        I = A - 9
                                        while i <= I:
                                            j = 1
                                            J = A - 10
                                            while j <= J:
                                                k = 1
                                                K = A - 11
                                                while k <= K:
                                                    l = 1
                                                    L = A - 12
                                                    while l <= L:
                                                        m = 1
                                                        M = A - 13
                                                        while m <= M:
                                                            o = 1
                                                            O = A - 14
                                                            while o <= O:
                                                                q = 1
                                                                Q = A - 15
                                                                while q <= Q:
                                                                    for value in pattern[
                                                                                 a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + 1:]:
                                                                        p = pattern[a] * pattern[a + b] * pattern[
                                                                            a + b + c] * \
                                                                            pattern[
                                                                                a + b + c + d] * pattern[
                                                                                a + b + c + d + e] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f] * pattern[
                                                                                a + b + c + d + e + f + g] * pattern[
                                                                                a + b + c + d + e + f + g + h] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f + g + h + i] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f + g + h + i + j] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f + g + h + i + j + k] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f + g + h + i + j + k + l] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o] * \
                                                                            pattern[
                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o + q] * value
                                                                        result.append(p)
                                                                    q += 1
                                                                o += 1
                                                            m += 1
                                                        l += 1
                                                    k += 1
                                                j += 1
                                            i += 1
                                        h += 1
                                    g += 1
                                f += 1
                            e += 1
                        d += 1
                    c += 1
                b += 1
            a += 1
    # Seventeenth
    elif n == 17:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                c = 1
                C = A - 3
                while c <= C:
                    d = 1
                    D = A - 4
                    while d <= D:
                        e = 1
                        E = A - 5
                        while e <= E:
                            f = 1
                            F = A - 6
                            while f <= F:
                                g = 1
                                G = A - 7
                                while g <= G:
                                    h = 1
                                    H = A - 8
                                    while h <= H:
                                        i = 1
                                        I = A - 9
                                        while i <= I:
                                            j = 1
                                            J = A - 10
                                            while j <= J:
                                                k = 1
                                                K = A - 11
                                                while k <= K:
                                                    l = 1
                                                    L = A - 12
                                                    while l <= L:
                                                        m = 1
                                                        M = A - 13
                                                        while m <= M:
                                                            o = 1
                                                            O = A - 14
                                                            while o <= O:
                                                                q = 1
                                                                Q = A - 15
                                                                while q <= Q:
                                                                    r = 1
                                                                    R = A - 16
                                                                    while r <= R:
                                                                        for value in pattern[
                                                                                     a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + 1:]:
                                                                            p = pattern[a] * pattern[a + b] * pattern[
                                                                                a + b + c] * pattern[
                                                                                    a + b + c + d] * pattern[
                                                                                    a + b + c + d + e] * pattern[
                                                                                    a + b + c + d + e + f] * pattern[
                                                                                    a + b + c + d + e + f + g] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i + j] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i + j + k] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i + j + k + l] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m + o] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m + o + q] * \
                                                                                pattern[
                                                                                    a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r] * value
                                                                            result.append(p)
                                                                        r += 1
                                                                    q += 1
                                                                o += 1
                                                            m += 1
                                                        l += 1
                                                    k += 1
                                                j += 1
                                            i += 1
                                        h += 1
                                    g += 1
                                f += 1
                            e += 1
                        d += 1
                    c += 1
                b += 1
            a += 1
    # Eighteenth
    elif n == 18:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                c = 1
                C = A - 3
                while c <= C:
                    d = 1
                    D = A - 4
                    while d <= D:
                        e = 1
                        E = A - 5
                        while e <= E:
                            f = 1
                            F = A - 6
                            while f <= F:
                                g = 1
                                G = A - 7
                                while g <= G:
                                    h = 1
                                    H = A - 8
                                    while h <= H:
                                        i = 1
                                        I = A - 9
                                        while i <= I:
                                            j = 1
                                            J = A - 10
                                            while j <= J:
                                                k = 1
                                                K = A - 11
                                                while k <= K:
                                                    l = 1
                                                    L = A - 12
                                                    while l <= L:
                                                        m = 1
                                                        M = A - 13
                                                        while m <= M:
                                                            o = 1
                                                            O = A - 14
                                                            while o <= O:
                                                                q = 1
                                                                Q = A - 15
                                                                while q <= Q:
                                                                    r = 1
                                                                    R = A - 16
                                                                    while r <= R:
                                                                        s = 1
                                                                        S = A - 17
                                                                        while s <= S:
                                                                            for value in pattern[
                                                                                         a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + 1:]:
                                                                                p = pattern[a] * pattern[a + b] * \
                                                                                    pattern[
                                                                                        a + b + c] * pattern[
                                                                                        a + b + c + d] * pattern[
                                                                                        a + b + c + d + e] * pattern[
                                                                                        a + b + c + d + e + f] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j + k] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j + k + l] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r] * \
                                                                                    pattern[
                                                                                        a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s] * value
                                                                                result.append(p)
                                                                            s += 1
                                                                        r += 1
                                                                    q += 1
                                                                o += 1
                                                            m += 1
                                                        l += 1
                                                    k += 1
                                                j += 1
                                            i += 1
                                        h += 1
                                    g += 1
                                f += 1
                            e += 1
                        d += 1
                    c += 1
                b += 1
            a += 1
    # Nineteenth
    elif n == 19:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                c = 1
                C = A - 3
                while c <= C:
                    d = 1
                    D = A - 4
                    while d <= D:
                        e = 1
                        E = A - 5
                        while e <= E:
                            f = 1
                            F = A - 6
                            while f <= F:
                                g = 1
                                G = A - 7
                                while g <= G:
                                    h = 1
                                    H = A - 8
                                    while h <= H:
                                        i = 1
                                        I = A - 9
                                        while i <= I:
                                            j = 1
                                            J = A - 10
                                            while j <= J:
                                                k = 1
                                                K = A - 11
                                                while k <= K:
                                                    l = 1
                                                    L = A - 12
                                                    while l <= L:
                                                        m = 1
                                                        M = A - 13
                                                        while m <= M:
                                                            o = 1
                                                            O = A - 14
                                                            while o <= O:
                                                                q = 1
                                                                Q = A - 15
                                                                while q <= Q:
                                                                    r = 1
                                                                    R = A - 16
                                                                    while r <= R:
                                                                        s = 1
                                                                        S = A - 17
                                                                        while s <= S:
                                                                            t = 1
                                                                            T = A - 18
                                                                            while t <= T:
                                                                                for value in pattern[
                                                                                             a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + 1:]:
                                                                                    p = pattern[a] * pattern[a + b] * \
                                                                                        pattern[
                                                                                            a + b + c] * pattern[
                                                                                            a + b + c + d] * pattern[
                                                                                            a + b + c + d + e] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k + l] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m + o] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m + o + q] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s] * \
                                                                                        pattern[
                                                                                            a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t] * value
                                                                                    result.append(p)
                                                                                t += 1
                                                                            s += 1
                                                                        r += 1
                                                                    q += 1
                                                                o += 1
                                                            m += 1
                                                        l += 1
                                                    k += 1
                                                j += 1
                                            i += 1
                                        h += 1
                                    g += 1
                                f += 1
                            e += 1
                        d += 1
                    c += 1
                b += 1
            a += 1
    # Twentieth
    elif n == 20:
        while a <= A:
            b = 1
            B = A - 2
            while b <= B:
                c = 1
                C = A - 3
                while c <= C:
                    d = 1
                    D = A - 4
                    while d <= D:
                        e = 1
                        E = A - 5
                        while e <= E:
                            f = 1
                            F = A - 6
                            while f <= F:
                                g = 1
                                G = A - 7
                                while g <= G:
                                    h = 1
                                    H = A - 8
                                    while h <= H:
                                        i = 1
                                        I = A - 9
                                        while i <= I:
                                            j = 1
                                            J = A - 10
                                            while j <= J:
                                                k = 1
                                                K = A - 11
                                                while k <= K:
                                                    l = 1
                                                    L = A - 12
                                                    while l <= L:
                                                        m = 1
                                                        M = A - 13
                                                        while m <= M:
                                                            o = 1
                                                            O = A - 14
                                                            while o <= O:
                                                                q = 1
                                                                Q = A - 15
                                                                while q <= Q:
                                                                    r = 1
                                                                    R = A - 16
                                                                    while r <= R:
                                                                        s = 1
                                                                        S = A - 17
                                                                        while s <= S:
                                                                            t = 1
                                                                            T = A - 18
                                                                            while t <= T:
                                                                                u = 1
                                                                                U = A - 19
                                                                                while u <= U:
                                                                                    for value in pattern[
                                                                                                 a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u + 1:]:
                                                                                        p = pattern[a] * pattern[
                                                                                            a + b] * \
                                                                                            pattern[
                                                                                                a + b + c] * pattern[
                                                                                                a + b + c + d] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o + q] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t] * \
                                                                                            pattern[
                                                                                                a + b + c + d + e + f + g + h + i + j + k + l + m + o + q + r + s + t + u] * value
                                                                                        result.append(p)
                                                                                    u += 1
                                                                                t += 1
                                                                            s += 1
                                                                        r += 1
                                                                    q += 1
                                                                o += 1
                                                            m += 1
                                                        l += 1
                                                    k += 1
                                                j += 1
                                            i += 1
                                        h += 1
                                    g += 1
                                f += 1
                            e += 1
                        d += 1
                    c += 1
                b += 1
            a += 1
    return sum(result)
