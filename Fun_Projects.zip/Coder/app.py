from Polynomial_Pattern_Determiner import PolDet
import  math
from Pascals_Triangle import Pascal
from Rv import Rv
from Nk import Nk
from Primes import Primes_Under
from Nkwinikaan import Nkwiks

# Name= input('What is our Name?')
# Password= input('What is your password?')
# Password_Length = len(Password)
# Stars= '*'*Password_Length print(f'{Name}, Your Password {Stars} is {Password_Length} letters long')


# H=['n','N','j']
# H.sort()
print(Nk(6,5))

# print(list(range(20)))

print('l'.join(['I']))


# a,b,c,*other,d,e =[1,2,3,4,5,6,7,8,9,10]
# print(other)



print('a'+'b')