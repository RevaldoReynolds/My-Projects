def Nkw(r, n, p):
    import math
    S = (math.factorial(n) * (p ** r)) / (math.factorial(r) * math.factorial(n - r))
    return S
