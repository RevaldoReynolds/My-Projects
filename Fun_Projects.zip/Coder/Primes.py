import math


def Primes_Under(n):
    '''
    returns a list of primes under the number including n if it is prime
    :param n: any positive integer
    :return: list of primes under n if n is prime
    '''
    s = 2
    P = []
    Potentials = []
    while s <= n:
        Potentials.append(s)
        s += 1
    for p in Potentials:
        h = Potentials[0]
        P.append(h)
        d = 0
        while d <= len(Potentials):
            g = h * d
            if g in Potentials:
                Potentials.remove(g)
            d += 1
    Primes = P + Potentials
    return Primes


def Is_prime(number):
    '''
    checks if the number is prime
    :param number: any positive integer
    :return: True or False
    '''
    if number in Primes_Under(number):
        return True
    else:
        return False


def Number_of_primes_under(n):
    '''
    calculates the number of primes under n including n if n is also prime
    :param n: any positive integer
    :return: the number of primes under n including n if n is also prime
    '''
    return len(Primes_Under(n))

