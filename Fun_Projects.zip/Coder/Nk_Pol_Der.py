from Polynomial_Pattern_Determiner import PolDet
from Nk import Nk
from Rv import Rv
import math

l = 0
n = 10
H = []
while l <= n:
    k = 0
    R = []
    while k <= l:
        P = Nk(k, l)
        H.append(P)
        k += 1
    j = -1
    while j <= l:
        V = l - j
        R.append(V)
        j += 1
    r = 0
    M = []
    while r <= l:
        Z = H[r] * R[r]
        M.append(Z)
        r += 1
    print(M)
    print(sum(M))
    l += 1
    H.clear()
