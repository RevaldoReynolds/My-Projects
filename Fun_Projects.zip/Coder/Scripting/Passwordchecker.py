import requests
import hashlib
import sys

def request_api_data(password) :
    url = 'https://api.pwnedpasswords.com/range/' + f'{password}'
    request = requests.get(url)
    if request.status_code != 200 :
        raise RuntimeError(f'Fetching Error : {request.status_code} Just check the API and try again')
    return request

def password_leaks_count(response,tail) :
    hashes = (lines.split(':') for lines in response.text.splitlines())
    for hash, number in hashes :
        if hash == tail :
            return number
    return 0

def pwned_api_check(password):
    hashedpass = hashlib.sha1(password.encode('utf-8')).hexdigest().upper()
    first5 , tail = hashedpass[:5] ,hashedpass[5:]
    response = request_api_data(first5)
    return password_leaks_count(response,tail)


def passwordchecker(passwords) :
    for password in passwords :
        count = pwned_api_check(password)
        if count :
            print(f'Your password "{password}" has been found {count} times. You should probably change it.')
        else :
            print(f'Your password "{password}" has never been pwned. You\'re good you can continue using it.')

if __name__ == '__main__' :
    passwordchecker(sys.argv[1:])
