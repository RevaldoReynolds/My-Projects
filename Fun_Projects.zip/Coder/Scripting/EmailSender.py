import smtplib
from email.message import EmailMessage

email = EmailMessage()

email['from'] = 'Fezgud Numbule'
email['to'] = 'revaldonkwinika1@gmail.com'
email['subject'] = 'I can now send emails with python'

email.set_content('''
Hey Revaldo! \n
\n
I can now send emails with Python bro. Actually I sent this email using python how great is that. Man you gotta try this it's awesome \n
ps Your boy Fezzy \n 
You never lived till you risk your life''')


smtp = smtplib.SMTP(host='smtp.gmail.com',port=587)
smtp.ehlo()
smtp.starttls()
smtp.send_message(email)
smtp.login('maququzelimkhatha@gmail.com','QUQUZELI@1')
