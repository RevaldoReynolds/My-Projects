from twilio.rest import Client

account_sid = 'AC788f3549cf8ff00a8cd020caf2bf3cfb'
auth_token = 'fcfd42ae2f8fbf53794a7745f326bfbb'
client = Client(account_sid, auth_token)

message = client.messages.create(
    from_='+12282075144',
    body='ybvvvvvvvvvvvvvvvvvvvvvvvvvvvvvujkkoihunvkjhvjnmoihiodklhnudvhndvh9iodknclkcjxmokdcn k,cxn xjmnc xkl,m k',
    to='+27764893810'
)

print(message.sid)