from Polynomial_Pattern_Determiner import PolDet
import math
from Primes import Primes_Under
