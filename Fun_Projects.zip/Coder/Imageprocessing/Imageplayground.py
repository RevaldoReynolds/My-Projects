from PIL import Image

picture=Image.open('Bulbasaur.jpg')