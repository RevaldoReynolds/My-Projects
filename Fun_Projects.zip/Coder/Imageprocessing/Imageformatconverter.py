import os
from PIL import Image

for path, diretory, filename in os.walk('\\Users\Revalddd\Coder/Imageprocessing/Pokedex'):
    for file in filename:
        split = os.path.splitext(file)
        format = split[1]
        if format == '.jpg':
            Photo = Image.open('\\Users\Revalddd\Coder/Imageprocessing/Pokedex/'+file)
            if not os.path.isdir('Converted Images'):
                os.mkdir('Converted Images')
            os.chdir('\\Users\Revalddd\Coder/Converted Images')
            Name = split[0]
            Photo.save(Name + '.png', 'png')
