from math import gamma,log,e
from Mycodes.Rv import Rv
def summer(degree, term):
    total = 0
    for number in range(1,int(term) + 1):
        total += number ** degree
    return total

def Firstpart(r,n):
    return (((-1)**r)*((n-r)**n))/((gamma(r+1))*(gamma(n-r+1)))

def Secondpart(r,n):
    result=((gamma(n+1)*(summer(-1,n)))-(gamma(n-r+1)*(summer(-1,n-r))))/gamma(n-r+1)
    return result

def Thirdpart(r,n):
    return gamma(n+1)*(log(n-r,e)-(n/(n-r)))


def Ultimatefactorial(n):
    r=0
    total=0
    while r <= n-1:
        function=Firstpart(r,n)*(Secondpart(r,n)+Thirdpart(r,n))
        total += function
        r += 1
    return total

def Integrator(function,initial,final):
    def Yielder(function,initial,final):
        x=(final-initial)/1000000
        p = initial
        while p <= final :
            result=function(p)*x
            yield result
            p += x

    return sum(Yielder(function,initial,final))

def Differentiator(function,point):
    x=1/10000000
    result=(function(point+x)-function(point))/x
    return result

def fact(n):
    return Rv(n,n,n+1)
print(Ultimatefactorial(3))
print(Differentiator(gamma,3))
print(Differentiator(fact,5))


