from Mycodes.The1stBalanceFuction import Bal_1
from Mycodes.Nkwinikan_Operators import Nk,Nkwiks

def Nk1Int(p,n,Patter1,Pattern2) :
    return Bal_1(p,n,Patter1,Pattern2)


print(Nk1Int(2,10,[1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10]))

P= sum(Nk(1,10))*sum(Nk(1,10))

print(P)
