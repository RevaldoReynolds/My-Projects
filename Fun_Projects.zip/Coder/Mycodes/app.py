from Mycodes.Nkwinikan_Operators import *

#total print(Nkwinikan_Operators.NkVar(12,11,['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','q','r','s','t','u','v','w','x','y','z']))
def summer(degree, term):
    total = 0
    for number in range(1,term + 1):
        total += number ** degree
    return total

def Nksum(p,n):
    total=0
    for r in range(1,p) :
        v=(summer(r+1,n)*sum(Nk(p-r-1,n)))*((-1)**(r+1))
        total += v
    return total


n=12
p=1
while p <= n :
    print((Nksum(p,p)+p*sum(Nk(p,p)))/sum(Nk(1,p)))
    print(sum(Nk(p-1,p)))
    print('#' * 25)
    p += 1

