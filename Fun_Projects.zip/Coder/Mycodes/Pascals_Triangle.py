def Pascal(n) :
    import math
    x = 0
    Y = []
    while x <= n:
        V = ((math.factorial(n))/((math.factorial(x))*math.factorial(n-x)))*((-1)**x)
        Y.append(V)
        x+=1
    return Y


