import datetime


print(datetime.date.today().timetuple())