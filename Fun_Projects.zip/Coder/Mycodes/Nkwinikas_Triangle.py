import Nkwinikan_Operators

n = 20
Sum = []
l = 0
H = []
while l <= n:
    k = 0
    while k <= l:
        P = sum(Nkwinikan_Operators.Nk(k,l))
        H.append(P)
        k += 1
    print(H)
    print(sum(H))
    l += 1
    H.clear()
