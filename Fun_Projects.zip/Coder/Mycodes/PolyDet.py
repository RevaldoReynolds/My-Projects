from Mycodes.Rv import Rv
from Mycodes.Nkwinikan_Operators import Nk, Nkwiks, Number_of_Terms_or_Products_in_Nk,NkVar
from Mycodes.Polynomial_Pattern_Determiner import PolDet
from Mycodes.Primes import PrimesUnder,Number_of_primes_under
from Mycodes.Summer import Summer
from Mycodes.Fibonacci import Fib
from math import factorial
from Mycodes.Pascals_Triangle import Pascal
# print(NkVar(3,5,['a','b','c','d','e','f']
def RevNkw(degree,Pattern):
    pattern=[]
    terms=[]
    for i,j in Pattern:
        pattern.append(j)
        terms.append(i)
    coefficients=[]
    def Rev(degree,power,terms) :
        List = []
        for i in range(len(terms) - 1):
            a = terms[i]
            b = terms[i + 1]
            s = 0
            for item in range(a, b):
                s += Rv(1, power, item + 1)
            List.append(s)
        pattern = List[:]

        P = []
        R = Pascal(degree - 1)
        g = 0
        while g <= degree - 1:
            V = pattern[degree - 1 - g] * R[g]
            P.append(V)
            g += 1

        return sum(P)
    n=degree
    Q=[]
    l = 0
    while l <= n:
        li=[]
        k = 0
        if l == n:
            while k <= l:
                li.append((terms[0]) ** (n - k))
                k += 1
        else:
            while k <= l:
                li.append(Rev(n - l, n - k, terms))
                k += 1
        L = []
        R = Pascal(degree - l)
        g = 0
        while g <= degree - l:
            V = pattern[degree - l - g] * R[g]
            L.append(V)
            g += 1
        if len(coefficients) == 0:
            coefficients.append(sum(L)/(li[0]))
        else :
            h=0
            P=[]
            while h <= l-1:
                O=coefficients[h]*li[h]
                P.append(O)
                h += 1
            coefficients.append((sum(L)-sum(P))/li[-1])
        l += 1
        Q.append(li)
    return coefficients


print(RevNkw(2,[(2,6),(7,51),(12,146)]))
