def Fib(number):
    a=0
    b=1
    for i in range(number) :
        yield a
        v=b
        b=a+b
        a=v

