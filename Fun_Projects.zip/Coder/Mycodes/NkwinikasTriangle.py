from Mycodes.Nkwinikan_Operators import Nk
n = 24 
Sum = []
l = 0
H = []
while l <= n:
    k = 0
    while k <= l:
        P = sum(Nk(k,l))
        H.append(P)
        k += 1
    print(H)
    print(sum(H))
    l += 1
    H.clear()
