from random import randint

def Monty_Hall():
    while True :
        try :
            Input = (input('Choose any integer between 1 and 3:  '))
            check = float(Input)
        except ValueError:
            print('Please enter a number!')
            print('...')
            print('...')
            print('...')
            continue
        else :
            try :
                chosen_number = int(Input)
            except:
                print('Please enter an integer not a floating point number!!!')
                print('...')
                print('...')
                print('...')
                continue
            else :
                if 1<= chosen_number<= 3:
                    correct_number = randint(1, 3)
                    if correct_number == chosen_number :
                        while True:
                            c = randint(1,3)
                            if c != correct_number :
                                break
                        while True :
                            change = input(f'The revealed number is "{c}" and it is not the correct number. Do you wish to change? (Yes or No)').lower()
                            if change == 'yes' or change =='y' or change == 'yeah' or change == 'yep' or change == 'of course' :
                                while True:
                                    d = randint(1, 3)
                                    if d != chosen_number and d != c :
                                        chosen_number =d
                                        break
                                print(f'You have changed your number to "{chosen_number}". The correct answer is "{correct_number}". You guessed wrong, you shouldn\'t have changed!')
                                break

                            elif change == 'no' or change == 'n' or change == 'noo' or change  == 'nooo' or change == 'noooo' or change  == 'nooooo'  :
                                print(f'Your chosen number remains "{chosen_number}". The correct answer is "{correct_number}". You guessed right, good move by not changing!')
                                break
                            elif change == 'stop' or change == 's' :
                                print(':(',':(',':(',':(',':(',':(',':(',':(',':(',':(')
                                break



                            else :
                                print('Type YES` or NO please!!! Or type STOP to stop')
                                print('...')
                                print('...')

                    elif correct_number != chosen_number:
                        while True:
                            c = randint(1, 3)
                            if c != correct_number and  c!= chosen_number:
                                break

                        while True:
                            change = input(
                                f'The revealed number is "{c}" and it is not the correct number. Do you wish to change? (Yes or No) :  ').lower()
                            if change == 'yes' or change =='y' or change == 'yeah' or change == 'yep' or change == 'of course':
                                while True:
                                    d = randint(1, 3)
                                    if d != chosen_number and d != c:
                                        chosen_number = d
                                        break
                                print(
                                    f'You have changed your number to "{chosen_number}". The correct answer is "{correct_number}". You guessed right, good move by changing!')
                                break

                            elif  change == 'no' or change == 'n' or change == 'noo' or change  == 'nooo' or change == 'noooo' or change  == 'nooooo':
                                print(
                                    f'Your chosen number remains "{chosen_number}". The correct answer is "{correct_number}". You guessed wrong, you should have changed!')
                                break
                            elif change == 'stop' or change == 's' :
                                print(':(',':(',':(',':(',':(',':(',':(',':(',':(')
                                break


                            else:
                                print('Type YES or NO please!!! or type STOP to stop')
                                print('...')
                                print('...')

                else :
                    print('I said a number between 1 and 3 please!!!')
                    print('...')
                    print('...')
                    print('...')
                    continue
            print('...')
            print('...')
            print('...')
            a = input('Do you still wanna play? Yes or No : ').lower()
            if a == 'no' or a == 'n' or a == 'noo' or a == 'nooo' or a == 'noooo' or a == 'nooooo':
                print('All right then thanks for playing ;)')
                break
            elif a == 'yes' or a == 'y' or a == 'yeah' or a == 'yep' or a == 'of course':
                print('All right then let\'s have fun ;)')
            else:
                print('You should have typed either "Yes" or "No", but since I enjoy your company I\'ll assume you still want to play. So let\'s go!!!')
            print('...')
            print('...')
            print('...')



def Monty(n,should_change):
    chosen_number = n
    correct_number = randint(1, 3)
    if correct_number == chosen_number:
       if should_change :
            return 0
       else :
           return 1
    elif correct_number != chosen_number:
        if should_change:
            return 1
        else:
            return 0
def Monty_hall_odds(number_of_games):
    n = number_of_games
    a= 0
    b= 0
    for _ in range(n):
        ans = Monty(randint(1, 3), True)
        if ans == 1 :
            a += 1
        else :
            b += 1

    c=0
    d=0
    for _ in range(n):
        ans = Monty(randint(1, 3), False)
        if ans == 1:
            c += 1
        else:
            d += 1

    print('Change;')
    print(f'Win : {a}/{n} = {a/n}')
    print(f'lose : {b}/{n} = {b/n}')
    print('...')
    print('...')
    print('...')
    print('No change;')
    print(f'Win : {c}/{n} = {c/n}')
    print(f'lose : {d}/{n} = {d/n}')


Monty_Hall()
