def summer(degree, term):
    total = 0
    for number in range(1,int(term) + 1):
        total += number ** degree
    return total

def Summer(degree, term,Pattern):
    total = 0
    for i,j in enumerate(Pattern):
        total = total+ j**degree
        if i+1 == term :
            break
    return total