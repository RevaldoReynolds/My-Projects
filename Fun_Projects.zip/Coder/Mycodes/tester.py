import unittest
from Mycodes.Nkwinikan_Operators import Nk

class Testing(unittest.TestCase) :
    def test_Nk(self): #Note in order for the tester to test a function it must always begin with test_[name].(e.g if i want to test even number I use test.even
        n=6
        k=5
        result=sum(Nk(k,n))
        self.assertEqual(result,1764)

    def test_Nk1(self): #Note in order for the tester to test a function it must always begin with test_[name].(e.g if i want to test even number I use test.even
        n='buguj'
        k=5
        result=sum(Nk(k,n))
        self.assertIsInstance(result,E)



if __name__ == '__main__' :
    unittest.main()