def summer(degree, term):
    total = 0
    for number in range(1,term + 1):
        total += number ** degree
    return total