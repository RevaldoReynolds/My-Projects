
def Rv( n , p , m ) :
    import math
    x=0
    Y=[]
    while x<= n :
        V=((math.gamma(n+1))*((m-x)**p)*((-1)**x))/((math.gamma(x+1))*(math.gamma(n-x+1)))
        Y.append(V)
        x+=1
    return (sum(Y))
