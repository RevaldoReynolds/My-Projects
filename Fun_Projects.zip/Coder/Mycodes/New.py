from math import factorial
from Mycodes.Summer import Summer
from Mycodes.Primes import Is_prime, PrimesUnder
from Mycodes.Nkwinikan_Operators import Nkwiks
from math import factorial


