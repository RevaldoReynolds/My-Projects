from Mycodes.Nkwinikan_Operators import Nk,Nkwiks
def Bal_1(p,n,Pat1,Pat2) :
    def Patterna(power) :

        Pattern = []
        for i in range(10):
            Pattern.append(Pat1[i] * ((Pat2[i])**power))

        return Pattern
    PATTERN=[]
    for i in range(0,n) :
      A = ((-1)**i)*sum(Nkwiks(1,n,Patterna(i)))*sum(Nkwiks(p-i-1,n,Pat2) )
      PATTERN.append(A)

    return sum(PATTERN)