from time import time


def TimeCalculator(function):
    def Wrapfunction(*args, **kwargs):
        t1 = time()
        result = function(*args, **kwargs)
        t2 = time()
        print(f'This function {function} took {t2 - t1} to run')
        return result

    return Wrapfunction
