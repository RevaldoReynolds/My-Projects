from Mycodes.Nkwinikan_Operators import Nk
from Mycodes.Rv import Rv
from Mycodes.Summer import Summer
from Mycodes.Primes import  PrimesUnder


# Rv constants
def Rv_constant(r):
    constant=0
    for x in range(r,89):
        constant += 1 / Rv(x-r,x,x+1)
        print(x+1-r,constant)

    return constant

#Nk_constants

def Nk_constant(r):
    constant=0
    for x in range(r,170+r):
        constant += 1 /sum(Nk(x-r,x))
        print(x+1-r,constant)
    return constant

b=1
Rv_constant(b)

#Prime constant
def PrimeConstant(z, n) :
    L = []
    p = 1
    k = 0
    for i in PrimesUnder(n):
        p = p * i

        k += 1/ p**z
        print(i, k)

    k = 1
    for k in L:
        print(Summer(-1, k, L))
        k += 1


print(PrimeConstant(10,1000))