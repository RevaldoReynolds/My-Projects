from Mycodes.Nkwinikan_Operators import *


def summer(degree, term):
    total = 0
    for number in range(term + 1):
        total += number ** degree
    return total


def Nksum(p, n):
    total = 0
    for r in range(1, p):
        v = (summer(r + 1, n) * sum(Nk(p - r - 1, n))) * ((-1) ** (r + 1))
        total += v
    return total


n = 89
p = 11
Nksum(p, n)
print(sum(Nk(1, n)) * sum(Nk(p - 1, n)) - p * sum(Nk(p, n)))
print(Nksum(p, n))
